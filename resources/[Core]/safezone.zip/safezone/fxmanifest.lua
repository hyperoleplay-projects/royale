fx_version 'cerulean'
game 'gta5'

shared_scripts {
    '@vrp/lib/utils.lua'
}

client_script{
    'client/main.lua', 

    'client/handlers/*.lua'
}

server_script{
    'server/main.lua', 

    'server/handlers/*.lua', 
    'server/modules/*.lua'
}