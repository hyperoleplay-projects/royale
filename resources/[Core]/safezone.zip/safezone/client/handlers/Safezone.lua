local cache = {}

Citizen.CreateThread(function()
    local fps, curtime, curframes = -1  
    local prevframes = GetGameTimer()
    local prevtime = GetFrameCount()

    while true do
        local sleepTime = 1000

        if cache.safezone then 
            sleepTime = 0

            while not NetworkIsPlayerActive(PlayerId()) or not NetworkIsSessionStarted() do	        
                Wait(100)

                prevframes = GetFrameCount()
                prevtime = GetGameTimer()            
            end

            curtime = GetGameTimer()
            curframes = GetFrameCount()	   
        
            if (curtime - prevtime) > 1000 then
                fps = (curframes - prevframes) - 1				
                prevtime = curtime
                prevframes = curframes
            end

            if cache.isRunning and cache.safezone.radius > cache.finaleRadius then 
                local serverFactor = (cache.initialRadius - cache.finaleRadius) / cache.timeToClose 
                local factor = serverFactor / fps

                cache.safezone.radius = cache.safezone.radius - factor
            end

            if not DoesBlipExist(cache.blip) then 
                cache.blip = AddBlipForRadius(cache.safezone.center.x, cache.safezone.center.y, cache.safezone.center.z, cache.safezone.radius)
            else 
                RemoveBlip(cache.blip)
                cache.blip = AddBlipForRadius(cache.safezone.center.x, cache.safezone.center.y, cache.safezone.center.z, cache.safezone.radius)
            end

            SetBlipColour(cache.blip, 3)
            SetBlipAlpha(cache.blip, 70)

            BeginTextCommandSetBlipName('STRING')
            AddTextComponentString('Safezone')
            EndTextCommandSetBlipName(cache.blip)
            
            DrawMarker(1, cache.safezone.center.x, cache.safezone.center.y, cache.safezone.center.z - 150, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, (cache.safezone.radius-1.3)*2, (cache.safezone.radius-1.3)*2, 250.0, 0, 85, 218, 140)
        else 
            if DoesBlipExist(cache.blip) then 
                RemoveBlip(cache.blip)
            end 
        end 
        
        Citizen.Wait(sleepTime)
    end
end)

RegisterNetEvent('safezone:updateSync', function(type, value)
    cache[type] = value

    if type == 'safezone' then
        if cache.safezone and not LocalPlayer.state.inSpec then 
            local playerPed = PlayerPedId()
            local pedCoordinates = GetEntityCoords(playerPed)
            local distance = #(pedCoordinates.xy - cache.safezone.center.xy) 

            if distance > cache.safezone.radius then 
                local health = GetEntityHealth(playerPed)
                local newHealth = health - GENERAL_CONFIG.DAMAGE_PER_SECOND 

                SetEntityHealth(playerPed, newHealth)
                
                TriggerEvent('gameEventTriggered', 'CEventLategameSafezone', { PlayerPedId(), nil })
            end
        end
    end
end)