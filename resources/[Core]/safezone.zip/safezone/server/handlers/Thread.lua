Citizen.CreateThread(function()
    while true do
        local currentTimestamp = os.time()
        local availableRooms = Safezone:Get()

        for index, object in ipairs(availableRooms) do
            local canStartSafezone = currentTimestamp > (object.createdAt + object.startAfter)

            print('canStartSafezone', canStartSafezone)

            if canStartSafezone then
                if not object.safezone.isRunning then
                    object.safezone.isRunning = true
                end

                local SAFEZONE_ROUTE = GENERAL_CONFIG.SAFEZONE_ROUTES[object.routeId][object.currentRoute]
                local NEXT_GENERAL_CONFIG.SAFEZONE_ROUTES[object.routeId][object.currentRoute + 1]

                if NEXT_GENERAL_CONFIG then
                    local canChangeRoute = currentTimestamp > (object.routeCreatedAt + SAFEZONE_ROUTE.DURATION)

                    print('canChangeRoute', canStartSafezone)

                    if canChangeRoute then
                        object.routeCreatedAt = os.time()
                        object.currentRoute = object.currentRoute + 1

                        print('MUDOU A ROTA', object.currentRoute)

                        SAFEZONE_ROUTE = GENERAL_CONFIG.SAFEZONE_ROUTES[object.routeId][object.currentRoute]

                        object.safezone.center = SAFEZONE_ROUTE.COORDINATES
                        object.safezone.radius = SAFEZONE_ROUTE.RADIUS / 1

                        object.safezone.initialRadius = SAFEZONE_ROUTE.RADIUS
                        object.safezone.finaleRadius = NEXT_GENERAL_CONFIG.RADIUS

                        object.safezone.timeToClose = SAFEZONE_ROUTE.DURATION
                    else
                        if object.safezone.radius > object.safezone.finaleRadius then 
                            local factor = (SAFEZONE_ROUTE.RADIUS - object.safezone.finaleRadius) / object.safezone.timeToClose
                            
                            object.safezone.radius = object.safezone.radius - factor
                        end 
                    end

                    print('SAFEZONE', json.encode(object.safezone, { indent = true }))

                    Triggers:Client('safezone:updateSync', object.game.players, 'safezone', object.safezone)
                else
                    print('NOT NEXT_GENERAL_CONFIG')
                end
            end
        end

        Citizen.Wait(1000)
    end
end)