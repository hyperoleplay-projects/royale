_G.Safezone = {
    cache = {}
}

--[[
    cache = {
        safezone = {
            radius
            center
        }
        
        isRunning
        initialRadius
        finaleRadius
        timeToClose
    }
]]

RegisterNetEvent("battle-CreateSafe")
AddEventHandler("battle-CreateSafe", function(...) 
    print('EVENTO - battle-CreateSafe', ...)
    
    Safezone:Create(...)
end)

RegisterNetEvent("battle-UpdatePlayersSafe")
AddEventHandler("battle-UpdatePlayersSafe", function(...) 
    Safezone:UpdatePlayers(...)
end)

function Safezone:Create(gameId, participants)
    local roomId = #self.cache + 1
    local routeId = math.random(#GENERAL_CONFIG.SAFEZONE_ROUTES)

    print('Safezone:Create', gameId, json.encode(participants))

    self.cache[roomId] = {
        roomId = roomId,
        routeId = routeId,

        isRunning = false, 

        currentRoute = 0, 

        createdAt = os.time(), 
        startAfter = GENERAL_CONFIG.START_AFTER,

        game = {
            id = gameId,
            players = participants
        },

        safezone = {}
    }
    
    for _, playerObject in pairs(participants) do 
        local playerSource = playerObject.source

        Player(playerSource).state.inGame = true
    end
end

function Safezone:GetIdentifierFromGameId(gameId)
    local roomId = nil

    for index, object in ipairs(self.cache) do
        if object.game.id == gameId then
            roomId = index

            break
        end
    end

    return roomId
end

function Safezone:UpdatePlayers(gameId, newPlayers)
    local roomId = self:GetIdentifierFromGameId(gameId)
    local roomObject = self:Get(roomId)

    if roomObject then
        roomObject.game.players = newPlayers
    end
end

function Safezone:Delete(roomId)
    local roomObject = self:Get(roomId)

    if roomObject then
        table.remove(self.cache, roomId)
    end
end

function Safezone:Get(roomId)
    if roomId then
        return self.cache[roomId]
    end

    return self.cache
end