local Tunnel = module('vrp', 'lib/Tunnel')
local Proxy = module('vrp', 'lib/Proxy')
vRPclient = Tunnel.getInterface('vRP')
vRP = Proxy.getInterface('vRP')

apiClient = Tunnel.getInterface('safezone')

api = {}
Tunnel.bindInterface('safezone', api)

GENERAL_CONFIG = module('config/general')