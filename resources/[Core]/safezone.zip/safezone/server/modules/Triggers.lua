_G.Triggers = {}

function Triggers:Client(eventName, playersTable, ...)
    local params = { ... }

    for _, playerObject in pairs(playersTable) do
        local playerSource = playerObject.source

        if not Player(playerSource).state.finishGameUI and not Player(playerSource).state.inSpec then
            TriggerClientEvent(eventName, playerSource, table.unpack(params))
        end
    end
end