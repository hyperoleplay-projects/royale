return {
    START_AFTER = 20,

    DAMAGE_PER_SECOND = 15,

    SAFEZONE_ROUTES = {
        -- Etapa de rota: { Centro (vector3), Radius (number), Duration (number) }
        { COORDINATES = vector3(-94.68, 881.03, 30.38), RADIUS = 2000.0, DURATION = 200 },
        { COORDINATES = vector3(-94.68, 881.03, 30.38), RADIUS = 1000.0, DURATION = 100 },
        { COORDINATES = vector3(-94.68, 881.03, 30.38), RADIUS = 500.0, DURATION = 20 },
        { COORDINATES = vector3(-94.68, 881.03, 30.38), RADIUS = 250.0, DURATION = 20 },
        { COORDINATES = vector3(-94.68, 881.03, 30.38), RADIUS = 100.0, DURATION = 10 },
        { COORDINATES = vector3(-94.68, 881.03, 30.38), RADIUS = 50.0, DURATION = 10 },
        { COORDINATES = vector3(-94.68, 881.03, 30.38), RADIUS = 0.0, DURATION = 0 } -- Essa etapa não move mais, ele finaliza o movimento, por isso não tem duração
    }
}